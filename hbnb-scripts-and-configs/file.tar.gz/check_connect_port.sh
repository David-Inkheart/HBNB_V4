#!/bin/bash
# configuring and checking a servert to listen on a port

if port open:

{

Connection to localhost 8848 port [tcp/*] succeeded!

}

else{

nc: connect to localhost port 8848 (tcp) failed: Connection refused!

}
