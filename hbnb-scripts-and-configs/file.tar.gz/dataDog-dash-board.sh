#!/usr/bin/env bash

# returns a dictionary of information on all hosts of client
# also returns status of query 'OK'

curl -X GET "https://api.datadoghq.com/api/v1/dashboard" -H "Accept: application/json" -H "DD-API-KEY: fdacd0da4cdfd7ee3a269bb61cf61eb9" -H "DD-APPLICATION-KEY: 16ae784ad401af9a1fdcd31a082dfb01064ede91"
